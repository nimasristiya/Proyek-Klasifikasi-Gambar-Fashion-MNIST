# Proyek Klasifikasi Gambar: Fashion MNIST
- **Nama:** Nimas Ristiya Rahma
- **Email:** nimasristiya@gmail.com
- **ID Dicoding:** nimasristiya

Sumber Dataset 
https://www.kaggle.com/datasets/zalando-research/fashionmnist

Submission projek akhir pada kelas "Belajar Pengembangan Machine Learning" Dicoding.

Dataset yang digunakan: Fashion MNIST<br/>
Acc      : 93%<br/>
Val Acc  : 90.8%